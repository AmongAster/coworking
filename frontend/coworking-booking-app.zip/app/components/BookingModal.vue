<script setup lang="ts">
import { z } from 'zod'
import type { FormSubmitEvent } from '@nuxt/ui'
import type { Room } from '~/types'

const props = defineProps<{
  room: Room | null
}>()

const emit = defineEmits<{
  booked: []
}>()

const open = defineModel<boolean>('open', { default: false })

const config = useRuntimeConfig()
const apiBase = config.public.apiBase
const { getAuthHeaders } = useAuth()
const toast = useToast()

const isLoading = ref(false)

const schema = z.object({
  booking_date: z.date({ required_error: 'Please select a date' }),
  start_time: z.string().min(1, 'Please select a start time'),
  end_time: z.string().min(1, 'Please select an end time')
}).refine(data => {
  if (data.start_time && data.end_time) {
    return data.start_time < data.end_time
  }
  return true
}, {
  message: 'End time must be after start time',
  path: ['end_time']
})

type Schema = z.output<typeof schema>

const state = reactive<{ booking_date: Date | undefined; start_time: string; end_time: string }>({
  booking_date: undefined,
  start_time: '',
  end_time: ''
})

// Time options from 7 AM to 10 PM
const timeOptions = computed(() => {
  const options = []
  for (let hour = 7; hour <= 22; hour++) {
    const time24 = `${hour.toString().padStart(2, '0')}:00`
    const period = hour >= 12 ? 'PM' : 'AM'
    const hour12 = hour > 12 ? hour - 12 : (hour === 0 ? 12 : hour)
    options.push({
      label: `${hour12}:00 ${period}`,
      value: time24
    })
  }
  return options
})

const resetForm = () => {
  state.booking_date = undefined
  state.start_time = ''
  state.end_time = ''
}

watch(open, (newValue) => {
  if (!newValue) {
    resetForm()
  }
})

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!props.room) return
  
  isLoading.value = true
  
  try {
    const formattedDate = event.data.booking_date.toISOString().split('T')[0]
    
    await $fetch(`${apiBase}/bookings`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: {
        room_id: props.room.id,
        booking_date: formattedDate,
        start_time: event.data.start_time,
        end_time: event.data.end_time
      }
    })
    
    toast.add({
      title: 'Booking confirmed!',
      description: `You have successfully booked ${props.room.name} for ${formattedDate}.`,
      color: 'success',
      icon: 'i-lucide-check-circle'
    })
    
    open.value = false
    emit('booked')
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to create booking'
    
    // Check for conflict
    const isConflict = errorMessage.toLowerCase().includes('conflict') || 
                       errorMessage.toLowerCase().includes('already booked')
    
    toast.add({
      title: isConflict ? 'Time slot unavailable' : 'Booking failed',
      description: isConflict 
        ? 'This time slot is already booked. Please select a different time.'
        : errorMessage,
      color: 'error',
      icon: 'i-lucide-alert-circle'
    })
  } finally {
    isLoading.value = false
  }
}

// Minimum date is today
const minDate = new Date()
minDate.setHours(0, 0, 0, 0)
</script>

<template>
  <UModal
    v-model:open="open"
    :title="`Book ${room?.name || 'Room'}`"
    :description="`Capacity: ${room?.capacity || 0} people`"
  >
    <template #body>
      <UForm :schema="schema" :state="state" class="space-y-6" @submit="onSubmit">
        <!-- Room Info -->
        <div class="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
          <div class="flex items-start gap-4">
            <div class="w-12 h-12 rounded-lg bg-indigo-600/20 flex items-center justify-center flex-shrink-0">
              <UIcon name="i-lucide-building" class="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h4 class="font-semibold text-white">{{ room?.name }}</h4>
              <p class="text-sm text-slate-400 mt-1">{{ room?.description }}</p>
            </div>
          </div>
        </div>
        
        <!-- Date Picker -->
        <UFormField name="booking_date" label="Select Date" required>
          <UPopover>
            <UButton
              variant="outline"
              block
              class="justify-start text-left font-normal"
              :class="{ 'text-slate-400': !state.booking_date }"
            >
              <UIcon name="i-lucide-calendar" class="w-4 h-4 mr-2" />
              {{ state.booking_date ? state.booking_date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : 'Pick a date' }}
            </UButton>
            
            <template #content>
              <UCalendar v-model="state.booking_date" />
            </template>
          </UPopover>
        </UFormField>
        
        <!-- Time Selection -->
        <div class="grid grid-cols-2 gap-4">
          <UFormField name="start_time" label="Start Time" required>
            <USelect
              v-model="state.start_time"
              :items="timeOptions"
              placeholder="Select start"
              icon="i-lucide-clock"
            />
          </UFormField>
          
          <UFormField name="end_time" label="End Time" required>
            <USelect
              v-model="state.end_time"
              :items="timeOptions"
              placeholder="Select end"
              icon="i-lucide-clock"
            />
          </UFormField>
        </div>
        
        <!-- Summary -->
        <div v-if="state.booking_date && state.start_time && state.end_time" class="p-4 rounded-lg bg-indigo-600/10 border border-indigo-500/30">
          <div class="flex items-center gap-2 text-indigo-400">
            <UIcon name="i-lucide-info" class="w-4 h-4" />
            <span class="text-sm font-medium">Booking Summary</span>
          </div>
          <p class="text-slate-300 mt-2 text-sm">
            {{ room?.name }} on {{ state.booking_date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) }} 
            from {{ state.start_time }} to {{ state.end_time }}
          </p>
        </div>
        
        <!-- Actions -->
        <div class="flex gap-3 pt-4">
          <UButton
            type="button"
            label="Cancel"
            variant="ghost"
            class="flex-1"
            @click="open = false"
          />
          <UButton
            type="submit"
            label="Confirm Booking"
            :loading="isLoading"
            class="flex-1"
            icon="i-lucide-check"
          />
        </div>
      </UForm>
    </template>
  </UModal>
</template>
