<script setup lang="ts">
import { z } from 'zod'
import type { FormSubmitEvent } from '@nuxt/ui'

definePageMeta({
  layout: false
})

useSeoMeta({
  title: 'Sign In - CoWork Space'
})

const { login, register, isAuthenticated } = useAuth()
const toast = useToast()

// Redirect if already authenticated
if (isAuthenticated.value) {
  navigateTo('/')
}

const isSignUp = ref(false)
const isLoading = ref(false)

const schema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters')
})

type Schema = z.output<typeof schema>

const state = reactive<Schema>({
  email: '',
  password: ''
})

const toggleMode = () => {
  isSignUp.value = !isSignUp.value
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  isLoading.value = true
  
  try {
    if (isSignUp.value) {
      await register(event.data.email, event.data.password)
      toast.add({
        title: 'Account created!',
        description: 'Welcome to CoWork Space.',
        color: 'success',
        icon: 'i-lucide-check-circle'
      })
    } else {
      await login(event.data.email, event.data.password)
      toast.add({
        title: 'Welcome back!',
        description: 'You have successfully signed in.',
        color: 'success',
        icon: 'i-lucide-check-circle'
      })
    }
    navigateTo('/')
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Authentication failed. Please try again.'
    toast.add({
      title: 'Error',
      description: errorMessage,
      color: 'error',
      icon: 'i-lucide-alert-circle'
    })
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <UApp :ui="{ colors: { primary: 'indigo', neutral: 'slate' } }">
    <div class="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div class="w-full max-w-md">
        <!-- Logo / Branding -->
        <div class="text-center mb-8">
          <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 mb-4">
            <UIcon name="i-lucide-building-2" class="w-8 h-8 text-white" />
          </div>
          <h1 class="text-2xl font-bold text-white">CoWork Space</h1>
          <p class="text-slate-400 mt-1">Book your perfect workspace</p>
        </div>
        
        <!-- Auth Card -->
        <UCard class="bg-slate-900/50 border-slate-800">
          <template #header>
            <div class="flex gap-2 p-1 bg-slate-800/50 rounded-lg">
              <button
                type="button"
                class="flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all"
                :class="!isSignUp ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'"
                @click="isSignUp = false"
              >
                Sign In
              </button>
              <button
                type="button"
                class="flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all"
                :class="isSignUp ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'"
                @click="isSignUp = true"
              >
                Sign Up
              </button>
            </div>
          </template>
          
          <UForm :schema="schema" :state="state" class="space-y-6" @submit="onSubmit">
            <UFormField name="email" label="Email Address">
              <UInput
                v-model="state.email"
                type="email"
                placeholder="you@example.com"
                icon="i-lucide-mail"
                size="lg"
                class="bg-slate-800/50"
              />
            </UFormField>
            
            <UFormField name="password" label="Password">
              <UInput
                v-model="state.password"
                type="password"
                placeholder="Enter your password"
                icon="i-lucide-lock"
                size="lg"
                class="bg-slate-800/50"
              />
            </UFormField>
            
            <UButton
              type="submit"
              :label="isSignUp ? 'Create Account' : 'Sign In'"
              :loading="isLoading"
              block
              size="lg"
              class="mt-6"
            />
          </UForm>
          
          <template #footer>
            <p class="text-center text-sm text-slate-400">
              {{ isSignUp ? 'Already have an account?' : "Don't have an account?" }}
              <button
                type="button"
                class="text-indigo-400 hover:text-indigo-300 font-medium ml-1"
                @click="toggleMode"
              >
                {{ isSignUp ? 'Sign in' : 'Sign up' }}
              </button>
            </p>
          </template>
        </UCard>
        
        <!-- Demo Credentials Notice -->
        <div class="mt-6 p-4 rounded-lg bg-slate-800/30 border border-slate-700">
          <div class="flex items-start gap-3">
            <UIcon name="i-lucide-info" class="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
            <div class="text-sm">
              <p class="text-slate-300 font-medium">Demo Mode</p>
              <p class="text-slate-400 mt-1">
                This frontend connects to an API at <code class="text-indigo-400">localhost:5000</code>. 
                Make sure your backend server is running.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </UApp>
</template>
