<script setup lang="ts">
import type { Room } from '~/types'

useSeoMeta({
  title: 'Room Catalog - CoWork Space'
})

const config = useRuntimeConfig()
const apiBase = config.public.apiBase
const { user, isAuthenticated, isAdmin, logout, getAuthHeaders } = useAuth()

// Fetch rooms
const { data: rooms, status: roomsStatus, refresh: refreshRooms } = await useFetch<Room[]>(`${apiBase}/rooms`, {
  key: 'rooms',
  default: () => []
})

// Search and filter
const searchQuery = ref('')
const capacityFilter = ref<number | null>(null)

const filteredRooms = computed(() => {
  if (!rooms.value) return []
  
  return rooms.value.filter(room => {
    const matchesSearch = room.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                          room.description.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesCapacity = !capacityFilter.value || room.capacity >= capacityFilter.value
    return matchesSearch && matchesCapacity
  })
})

// Booking modal state
const isBookingModalOpen = ref(false)
const selectedRoom = ref<Room | null>(null)

const openBookingModal = (room: Room) => {
  if (!isAuthenticated.value) {
    navigateTo('/login')
    return
  }
  selectedRoom.value = room
  isBookingModalOpen.value = true
}

const capacityOptions = [
  { label: 'Any capacity', value: null },
  { label: '2+ people', value: 2 },
  { label: '4+ people', value: 4 },
  { label: '6+ people', value: 6 },
  { label: '10+ people', value: 10 }
]

const userMenuItems = computed(() => [
  [
    {
      label: user.value?.email || 'User',
      slot: 'account',
      disabled: true
    }
  ],
  ...(isAdmin.value ? [[
    {
      label: 'Admin Panel',
      icon: 'i-lucide-shield',
      to: '/admin'
    }
  ]] : []),
  [
    {
      label: 'My Bookings',
      icon: 'i-lucide-calendar',
      to: '/bookings'
    }
  ],
  [
    {
      label: 'Sign Out',
      icon: 'i-lucide-log-out',
      color: 'error' as const,
      onSelect: () => logout()
    }
  ]
])
</script>

<template>
  <div class="min-h-screen bg-slate-950">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          <!-- Logo -->
          <NuxtLink to="/" class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
              <UIcon name="i-lucide-building-2" class="w-5 h-5 text-white" />
            </div>
            <span class="font-bold text-white text-lg hidden sm:block">CoWork Space</span>
          </NuxtLink>
          
          <!-- Right Side -->
          <div class="flex items-center gap-4">
            <template v-if="isAuthenticated">
              <NuxtLink to="/bookings">
                <UButton
                  label="My Bookings"
                  variant="ghost"
                  icon="i-lucide-calendar"
                  class="hidden sm:flex"
                />
              </NuxtLink>
              
              <UDropdownMenu :items="userMenuItems">
                <UButton variant="ghost" class="p-0">
                  <UAvatar 
                    :alt="user?.email || 'User'" 
                    icon="i-lucide-user"
                    size="sm"
                    class="bg-slate-700"
                  />
                </UButton>
                
                <template #account>
                  <div class="px-2 py-1.5">
                    <p class="text-sm font-medium text-white truncate">{{ user?.email }}</p>
                    <p class="text-xs text-slate-400">{{ user?.role || 'Member' }}</p>
                  </div>
                </template>
              </UDropdownMenu>
            </template>
            
            <template v-else>
              <NuxtLink to="/login">
                <UButton label="Sign In" variant="ghost" />
              </NuxtLink>
              <NuxtLink to="/login">
                <UButton label="Get Started" />
              </NuxtLink>
            </template>
          </div>
        </div>
      </div>
    </header>
    
    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <!-- Hero Section -->
      <div class="text-center mb-12">
        <h1 class="text-4xl font-bold text-white mb-4">Find Your Perfect Workspace</h1>
        <p class="text-lg text-slate-400 max-w-2xl mx-auto">
          Browse our available rooms and book the perfect space for your next meeting, focus session, or team collaboration.
        </p>
      </div>
      
      <!-- Search and Filters -->
      <div class="flex flex-col sm:flex-row gap-4 mb-8">
        <UInput
          v-model="searchQuery"
          placeholder="Search rooms by name or description..."
          icon="i-lucide-search"
          size="lg"
          class="flex-1 bg-slate-800/50"
        />
        <USelect
          v-model="capacityFilter"
          :items="capacityOptions"
          placeholder="Filter by capacity"
          size="lg"
          class="w-full sm:w-48 bg-slate-800/50"
        />
        <UButton 
          icon="i-lucide-refresh-cw" 
          variant="outline" 
          size="lg"
          @click="refreshRooms()"
        />
      </div>
      
      <!-- Loading State -->
      <div v-if="roomsStatus === 'pending'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <USkeleton v-for="i in 6" :key="i" class="h-80 rounded-xl" />
      </div>
      
      <!-- Empty State -->
      <UEmpty
        v-else-if="filteredRooms.length === 0"
        icon="i-lucide-search-x"
        title="No rooms found"
        description="Try adjusting your search or filter criteria."
        class="py-16"
      />
      
      <!-- Rooms Grid -->
      <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <UCard
          v-for="room in filteredRooms"
          :key="room.id"
          class="bg-slate-900/50 border-slate-800 hover:border-indigo-500/50 transition-all duration-300 group overflow-hidden"
        >
          <!-- Room Image -->
          <template #header>
            <div class="relative h-48 bg-gradient-to-br from-slate-800 to-slate-700 -mx-4 -mt-4 overflow-hidden">
              <img
                v-if="room.image_url"
                :src="room.image_url"
                :alt="room.name"
                class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div v-else class="absolute inset-0 flex items-center justify-center">
                <UIcon name="i-lucide-image" class="w-16 h-16 text-slate-600" />
              </div>
              
              <!-- Capacity Badge -->
              <div class="absolute top-4 right-4">
                <UBadge color="primary" variant="solid" class="backdrop-blur-sm">
                  <UIcon name="i-lucide-users" class="w-3 h-3 mr-1" />
                  {{ room.capacity }} people
                </UBadge>
              </div>
            </div>
          </template>
          
          <!-- Room Info -->
          <div class="space-y-4">
            <div>
              <h3 class="text-xl font-semibold text-white group-hover:text-indigo-400 transition-colors">
                {{ room.name }}
              </h3>
              <p class="text-slate-400 mt-2 line-clamp-2">
                {{ room.description }}
              </p>
            </div>
          </div>
          
          <template #footer>
            <UButton
              label="Book Now"
              icon="i-lucide-calendar-plus"
              block
              size="lg"
              @click="openBookingModal(room)"
            />
          </template>
        </UCard>
      </div>
    </main>
    
    <!-- Booking Modal -->
    <BookingModal
      v-model:open="isBookingModalOpen"
      :room="selectedRoom"
      @booked="refreshRooms()"
    />
  </div>
</template>
