<script setup lang="ts">
import type { Room, Booking, User } from '~/types'

definePageMeta({
  layout: 'admin',
  middleware: 'admin',
  title: 'Dashboard Overview'
})

useSeoMeta({
  title: 'Admin Dashboard - CoWork Space'
})

const config = useRuntimeConfig()
const apiBase = config.public.apiBase
const { getAuthHeaders } = useAuth()

// Fetch statistics
const { data: rooms, status: roomsStatus } = await useFetch<Room[]>(`${apiBase}/rooms`, {
  key: 'admin-rooms',
  default: () => []
})

const { data: bookings, status: bookingsStatus } = await useFetch<Booking[]>(`${apiBase}/bookings`, {
  key: 'admin-bookings',
  headers: getAuthHeaders(),
  default: () => []
})

const { data: users } = await useFetch<User[]>(`${apiBase}/users`, {
  key: 'admin-users',
  headers: getAuthHeaders(),
  default: () => []
})

// Computed statistics
const totalRooms = computed(() => rooms.value?.length || 0)
const totalBookings = computed(() => bookings.value?.length || 0)
const totalUsers = computed(() => users.value?.length || 0)

const todayBookings = computed(() => {
  const today = new Date().toISOString().split('T')[0]
  return bookings.value?.filter(b => b.booking_date === today) || []
})

const occupancyRate = computed(() => {
  if (!totalRooms.value || !todayBookings.value.length) return 0
  // Assuming each room can have up to 8 time slots per day
  const maxBookings = totalRooms.value * 8
  return Math.min(Math.round((todayBookings.value.length / maxBookings) * 100), 100)
})

const recentBookings = computed(() => {
  return [...(bookings.value || [])].sort((a, b) => {
    return new Date(b.booking_date).getTime() - new Date(a.booking_date).getTime()
  }).slice(0, 5)
})

const statsCards = computed(() => [
  {
    label: 'Total Bookings',
    value: totalBookings.value,
    icon: 'i-lucide-calendar-check',
    color: 'from-indigo-500 to-violet-600',
    change: '+12%',
    changeType: 'positive'
  },
  {
    label: 'Active Rooms',
    value: totalRooms.value,
    icon: 'i-lucide-door-open',
    color: 'from-emerald-500 to-teal-600',
    change: '+2',
    changeType: 'positive'
  },
  {
    label: 'Registered Users',
    value: totalUsers.value,
    icon: 'i-lucide-users',
    color: 'from-amber-500 to-orange-600',
    change: '+8%',
    changeType: 'positive'
  },
  {
    label: "Today's Occupancy",
    value: `${occupancyRate.value}%`,
    icon: 'i-lucide-activity',
    color: 'from-rose-500 to-pink-600',
    progress: occupancyRate.value,
    changeType: 'neutral'
  }
])

const isLoading = computed(() => roomsStatus.value === 'pending' || bookingsStatus.value === 'pending')

const formatTime = (time: string) => {
  const [hours, minutes] = time.split(':')
  const hour = parseInt(hours)
  const ampm = hour >= 12 ? 'PM' : 'AM'
  const hour12 = hour % 12 || 12
  return `${hour12}:${minutes} ${ampm}`
}
</script>

<template>
  <div class="space-y-8">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      <template v-if="isLoading">
        <USkeleton v-for="i in 4" :key="i" class="h-36 rounded-2xl" />
      </template>
      
      <template v-else>
        <div
          v-for="stat in statsCards"
          :key="stat.label"
          class="relative group overflow-hidden rounded-2xl bg-slate-900/50 border border-slate-800 p-6 hover:border-slate-700 transition-all duration-300"
        >
          <!-- Gradient Background Glow -->
          <div
            class="absolute -top-12 -right-12 w-32 h-32 rounded-full opacity-20 blur-2xl transition-opacity duration-300 group-hover:opacity-40"
            :class="`bg-gradient-to-br ${stat.color}`"
          />
          
          <div class="relative">
            <div class="flex items-center justify-between mb-4">
              <div
                class="w-12 h-12 rounded-xl flex items-center justify-center"
                :class="`bg-gradient-to-br ${stat.color}`"
              >
                <UIcon :name="stat.icon" class="w-6 h-6 text-white" />
              </div>
              
              <UBadge
                v-if="stat.change"
                :color="stat.changeType === 'positive' ? 'success' : 'neutral'"
                variant="subtle"
                size="xs"
              >
                {{ stat.change }}
              </UBadge>
            </div>
            
            <p class="text-3xl font-bold text-white mb-1">{{ stat.value }}</p>
            <p class="text-sm text-slate-400">{{ stat.label }}</p>
            
            <!-- Progress Bar for Occupancy -->
            <div v-if="stat.progress !== undefined" class="mt-4">
              <UProgress 
                :value="stat.progress" 
                :max="100"
                size="sm"
                class="bg-slate-800"
              />
            </div>
          </div>
        </div>
      </template>
    </div>
    
    <!-- Recent Activity -->
    <div class="rounded-2xl bg-slate-900/50 border border-slate-800 overflow-hidden">
      <div class="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h2 class="text-lg font-semibold text-white">Recent Activity</h2>
          <p class="text-sm text-slate-400">Latest bookings across the platform</p>
        </div>
        <NuxtLink to="/admin/bookings">
          <UButton
            label="View All"
            variant="ghost"
            trailing-icon="i-lucide-arrow-right"
            size="sm"
          />
        </NuxtLink>
      </div>
      
      <div v-if="isLoading" class="p-6 space-y-4">
        <USkeleton v-for="i in 5" :key="i" class="h-16 rounded-xl" />
      </div>
      
      <div v-else-if="recentBookings.length === 0" class="p-12">
        <UEmpty
          icon="i-lucide-calendar-x"
          title="No bookings yet"
          description="Bookings will appear here once users start making reservations."
        />
      </div>
      
      <div v-else class="divide-y divide-slate-800">
        <div
          v-for="booking in recentBookings"
          :key="booking.id"
          class="px-6 py-4 flex items-center gap-4 hover:bg-slate-800/30 transition-colors"
        >
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500/20 to-violet-500/20 flex items-center justify-center border border-indigo-500/30">
            <UIcon name="i-lucide-calendar" class="w-5 h-5 text-indigo-400" />
          </div>
          
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium text-white">
              {{ booking.room_name || `Room #${booking.room_id}` }}
            </p>
            <p class="text-xs text-slate-400">
              User #{{ booking.user_id }}
            </p>
          </div>
          
          <div class="text-right">
            <p class="text-sm text-white">{{ booking.booking_date }}</p>
            <p class="text-xs text-slate-400">
              {{ formatTime(booking.start_time) }} - {{ formatTime(booking.end_time) }}
            </p>
          </div>
          
          <UBadge color="success" variant="subtle" size="xs">
            Confirmed
          </UBadge>
        </div>
      </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <NuxtLink to="/admin/rooms" class="group">
        <div class="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 p-6 hover:border-indigo-500/50 transition-all duration-300">
          <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <UIcon name="i-lucide-plus" class="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 class="text-lg font-semibold text-white group-hover:text-indigo-400 transition-colors">Add New Room</h3>
              <p class="text-sm text-slate-400">Create a new coworking space</p>
            </div>
          </div>
        </div>
      </NuxtLink>
      
      <NuxtLink to="/admin/bookings" class="group">
        <div class="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 p-6 hover:border-emerald-500/50 transition-all duration-300">
          <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <UIcon name="i-lucide-list-checks" class="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 class="text-lg font-semibold text-white group-hover:text-emerald-400 transition-colors">Manage Bookings</h3>
              <p class="text-sm text-slate-400">View and manage all reservations</p>
            </div>
          </div>
        </div>
      </NuxtLink>
    </div>
  </div>
</template>
