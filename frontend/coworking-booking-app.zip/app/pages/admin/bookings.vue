<script setup lang="ts">
import type { Room, Booking } from '~/types'

definePageMeta({
  layout: 'admin',
  middleware: 'admin',
  title: 'Booking Management'
})

useSeoMeta({
  title: 'Booking Management - Admin - CoWork Space'
})

const config = useRuntimeConfig()
const apiBase = config.public.apiBase
const { getAuthHeaders } = useAuth()
const toast = useToast()

// Fetch all bookings
const { data: bookings, status, refresh } = await useFetch<Booking[]>(`${apiBase}/bookings`, {
  key: 'admin-all-bookings',
  headers: getAuthHeaders(),
  default: () => []
})

// Fetch rooms for filter
const { data: rooms } = await useFetch<Room[]>(`${apiBase}/rooms`, {
  key: 'admin-rooms-filter',
  default: () => []
})

// Filters
const selectedRoom = ref<number | null>(null)
const selectedDate = ref<string>('')

const filteredBookings = computed(() => {
  if (!bookings.value) return []
  
  return bookings.value.filter(booking => {
    const matchesRoom = !selectedRoom.value || booking.room_id === selectedRoom.value
    const matchesDate = !selectedDate.value || booking.booking_date === selectedDate.value
    return matchesRoom && matchesDate
  }).sort((a, b) => {
    // Sort by date descending, then by start time
    const dateCompare = new Date(b.booking_date).getTime() - new Date(a.booking_date).getTime()
    if (dateCompare !== 0) return dateCompare
    return a.start_time.localeCompare(b.start_time)
  })
})

const roomOptions = computed(() => [
  { label: 'All Rooms', value: null },
  ...(rooms.value?.map(room => ({
    label: room.name,
    value: room.id
  })) || [])
])

// Cancel booking
const cancelBookingId = ref<number | null>(null)
const isCancelDialogOpen = ref(false)
const isCancelling = ref(false)

const openCancelDialog = (bookingId: number) => {
  cancelBookingId.value = bookingId
  isCancelDialogOpen.value = true
}

const confirmCancelBooking = async () => {
  if (!cancelBookingId.value) return
  
  isCancelling.value = true
  
  try {
    await $fetch(`${apiBase}/bookings/${cancelBookingId.value}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    })
    
    toast.add({
      title: 'Booking Cancelled',
      description: 'The booking has been revoked successfully.',
      icon: 'i-lucide-check-circle',
      color: 'success'
    })
    
    isCancelDialogOpen.value = false
    cancelBookingId.value = null
    await refresh()
  } catch (error: any) {
    toast.add({
      title: 'Error',
      description: error?.data?.message || 'Failed to cancel booking.',
      icon: 'i-lucide-alert-circle',
      color: 'error'
    })
  } finally {
    isCancelling.value = false
  }
}

const clearFilters = () => {
  selectedRoom.value = null
  selectedDate.value = ''
}

const formatTime = (time: string) => {
  const [hours, minutes] = time.split(':')
  const hour = parseInt(hours)
  const ampm = hour >= 12 ? 'PM' : 'AM'
  const hour12 = hour % 12 || 12
  return `${hour12}:${minutes} ${ampm}`
}

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr)
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  })
}

const isUpcoming = (dateStr: string) => {
  const bookingDate = new Date(dateStr)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return bookingDate >= today
}

const bookingToCancel = computed(() => {
  return bookings.value?.find(b => b.id === cancelBookingId.value)
})

const columns = [
  { key: 'id', label: 'ID' },
  { key: 'room', label: 'Room' },
  { key: 'user', label: 'User' },
  { key: 'date', label: 'Date' },
  { key: 'time', label: 'Time Slot' },
  { key: 'status', label: 'Status' },
  { key: 'actions', label: 'Actions' }
]

const hasActiveFilters = computed(() => selectedRoom.value !== null || selectedDate.value !== '')
</script>

<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold text-white">Booking Management</h1>
        <p class="text-slate-400 mt-1">View and manage all reservations across the platform</p>
      </div>
      
      <UButton
        icon="i-lucide-refresh-cw"
        variant="outline"
        :loading="status === 'pending'"
        @click="refresh()"
      >
        Refresh
      </UButton>
    </div>
    
    <!-- Filters -->
    <div class="flex flex-col sm:flex-row gap-4">
      <USelect
        v-model="selectedRoom"
        :items="roomOptions"
        placeholder="Filter by room"
        class="w-full sm:w-64"
        icon="i-lucide-door-open"
      />
      
      <UInput
        v-model="selectedDate"
        type="date"
        placeholder="Filter by date"
        class="w-full sm:w-48"
      />
      
      <UButton
        v-if="hasActiveFilters"
        icon="i-lucide-x"
        variant="ghost"
        label="Clear Filters"
        @click="clearFilters"
      />
      
      <div class="flex-1" />
      
      <UBadge v-if="filteredBookings.length > 0" variant="subtle" size="lg">
        {{ filteredBookings.length }} booking{{ filteredBookings.length !== 1 ? 's' : '' }}
      </UBadge>
    </div>
    
    <!-- Bookings Table -->
    <div class="rounded-2xl bg-slate-900/50 border border-slate-800 overflow-hidden">
      <div v-if="status === 'pending'" class="p-6 space-y-4">
        <USkeleton v-for="i in 8" :key="i" class="h-16 rounded-xl" />
      </div>
      
      <div v-else-if="!filteredBookings.length" class="p-12">
        <UEmpty
          icon="i-lucide-calendar-x"
          :title="hasActiveFilters ? 'No matching bookings' : 'No bookings found'"
          :description="hasActiveFilters ? 'Try adjusting your filters to see more results.' : 'Bookings will appear here once users start making reservations.'"
        >
          <template v-if="hasActiveFilters" #actions>
            <UButton
              label="Clear Filters"
              variant="outline"
              icon="i-lucide-x"
              @click="clearFilters"
            />
          </template>
        </UEmpty>
      </div>
      
      <UTable v-else :data="filteredBookings" :columns="columns" class="w-full">
        <template #id-cell="{ row }">
          <span class="text-slate-400 font-mono text-sm">#{{ row.original.id }}</span>
        </template>
        
        <template #room-cell="{ row }">
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
              <UIcon name="i-lucide-door-open" class="w-4 h-4 text-indigo-400" />
            </div>
            <span class="font-medium text-white">
              {{ row.original.room_name || `Room #${row.original.room_id}` }}
            </span>
          </div>
        </template>
        
        <template #user-cell="{ row }">
          <div class="flex items-center gap-2">
            <UAvatar
              icon="i-lucide-user"
              size="xs"
              class="bg-slate-700"
            />
            <span class="text-slate-300">User #{{ row.original.user_id }}</span>
          </div>
        </template>
        
        <template #date-cell="{ row }">
          <span class="text-white">{{ formatDate(row.original.booking_date) }}</span>
        </template>
        
        <template #time-cell="{ row }">
          <div class="flex items-center gap-1 text-slate-300">
            <UIcon name="i-lucide-clock" class="w-4 h-4 text-slate-500" />
            {{ formatTime(row.original.start_time) }} - {{ formatTime(row.original.end_time) }}
          </div>
        </template>
        
        <template #status-cell="{ row }">
          <UBadge
            :color="isUpcoming(row.original.booking_date) ? 'success' : 'neutral'"
            variant="subtle"
          >
            {{ isUpcoming(row.original.booking_date) ? 'Upcoming' : 'Past' }}
          </UBadge>
        </template>
        
        <template #actions-cell="{ row }">
          <UButton
            v-if="isUpcoming(row.original.booking_date)"
            icon="i-lucide-x"
            label="Revoke"
            color="error"
            variant="ghost"
            size="sm"
            @click="openCancelDialog(row.original.id)"
          />
          <span v-else class="text-slate-500 text-sm">-</span>
        </template>
      </UTable>
    </div>
    
    <!-- Cancel Confirmation Dialog -->
    <UModal v-model:open="isCancelDialogOpen">
      <template #content>
        <UCard class="w-full max-w-md">
          <template #header>
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                <UIcon name="i-lucide-alert-triangle" class="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 class="text-lg font-semibold text-white">Revoke Booking</h3>
                <p class="text-sm text-slate-400">This will cancel the reservation</p>
              </div>
            </div>
          </template>
          
          <div v-if="bookingToCancel" class="space-y-3">
            <p class="text-slate-300">
              Are you sure you want to revoke this booking?
            </p>
            
            <div class="rounded-xl bg-slate-800/50 border border-slate-700 p-4 space-y-2">
              <div class="flex justify-between">
                <span class="text-slate-400">Room</span>
                <span class="text-white font-medium">{{ bookingToCancel.room_name || `Room #${bookingToCancel.room_id}` }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Date</span>
                <span class="text-white">{{ formatDate(bookingToCancel.booking_date) }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Time</span>
                <span class="text-white">{{ formatTime(bookingToCancel.start_time) }} - {{ formatTime(bookingToCancel.end_time) }}</span>
              </div>
            </div>
          </div>
          
          <template #footer>
            <div class="flex gap-3 justify-end">
              <UButton
                label="Keep Booking"
                variant="ghost"
                @click="isCancelDialogOpen = false"
              />
              <UButton
                label="Revoke Booking"
                color="error"
                :loading="isCancelling"
                @click="confirmCancelBooking"
              />
            </div>
          </template>
        </UCard>
      </template>
    </UModal>
  </div>
</template>
