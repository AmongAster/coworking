<script setup lang="ts">
import { z } from 'zod'
import type { Room } from '~/types'
import type { FormSubmitEvent } from '#ui/types'

definePageMeta({
  layout: 'admin',
  middleware: 'admin',
  title: 'Room Management'
})

useSeoMeta({
  title: 'Room Management - Admin - CoWork Space'
})

const config = useRuntimeConfig()
const apiBase = config.public.apiBase
const { getAuthHeaders } = useAuth()
const toast = useToast()

// Fetch rooms
const { data: rooms, status, refresh } = await useFetch<Room[]>(`${apiBase}/rooms`, {
  key: 'admin-rooms-list',
  default: () => []
})

// Create room modal
const isCreateModalOpen = ref(false)
const isCreating = ref(false)

const createRoomSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  capacity: z.number().min(1, 'Capacity must be at least 1'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  image_url: z.string().url('Must be a valid URL').optional().or(z.literal(''))
})

type CreateRoomSchema = z.output<typeof createRoomSchema>

const createRoomState = reactive<CreateRoomSchema>({
  name: '',
  capacity: 4,
  description: '',
  image_url: ''
})

const resetCreateForm = () => {
  createRoomState.name = ''
  createRoomState.capacity = 4
  createRoomState.description = ''
  createRoomState.image_url = ''
}

const onCreateRoom = async (event: FormSubmitEvent<CreateRoomSchema>) => {
  isCreating.value = true
  
  try {
    await $fetch(`${apiBase}/rooms`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: {
        name: event.data.name,
        capacity: event.data.capacity,
        description: event.data.description,
        image_url: event.data.image_url || null
      }
    })
    
    toast.add({
      title: 'Room Created',
      description: `${event.data.name} has been added successfully.`,
      icon: 'i-lucide-check-circle',
      color: 'success'
    })
    
    isCreateModalOpen.value = false
    resetCreateForm()
    await refresh()
  } catch (error: any) {
    toast.add({
      title: 'Error',
      description: error?.data?.message || 'Failed to create room.',
      icon: 'i-lucide-alert-circle',
      color: 'error'
    })
  } finally {
    isCreating.value = false
  }
}

// Delete room
const deleteRoomId = ref<number | null>(null)
const isDeleteDialogOpen = ref(false)
const isDeleting = ref(false)

const openDeleteDialog = (roomId: number) => {
  deleteRoomId.value = roomId
  isDeleteDialogOpen.value = true
}

const confirmDeleteRoom = async () => {
  if (!deleteRoomId.value) return
  
  isDeleting.value = true
  
  try {
    await $fetch(`${apiBase}/rooms/${deleteRoomId.value}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    })
    
    toast.add({
      title: 'Room Deleted',
      description: 'The room has been removed successfully.',
      icon: 'i-lucide-check-circle',
      color: 'success'
    })
    
    isDeleteDialogOpen.value = false
    deleteRoomId.value = null
    await refresh()
  } catch (error: any) {
    toast.add({
      title: 'Error',
      description: error?.data?.message || 'Failed to delete room.',
      icon: 'i-lucide-alert-circle',
      color: 'error'
    })
  } finally {
    isDeleting.value = false
  }
}

// Table columns
const columns = [
  { key: 'image', label: 'Image' },
  { key: 'name', label: 'Name' },
  { key: 'capacity', label: 'Capacity' },
  { key: 'description', label: 'Description' },
  { key: 'actions', label: 'Actions' }
]

const roomToDelete = computed(() => {
  return rooms.value?.find(r => r.id === deleteRoomId.value)
})
</script>

<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold text-white">Room Management</h1>
        <p class="text-slate-400 mt-1">Manage your coworking spaces and meeting rooms</p>
      </div>
      
      <UButton
        label="Create New Room"
        icon="i-lucide-plus"
        @click="isCreateModalOpen = true"
      />
    </div>
    
    <!-- Rooms Table -->
    <div class="rounded-2xl bg-slate-900/50 border border-slate-800 overflow-hidden">
      <div v-if="status === 'pending'" class="p-6 space-y-4">
        <USkeleton v-for="i in 5" :key="i" class="h-20 rounded-xl" />
      </div>
      
      <div v-else-if="!rooms?.length" class="p-12">
        <UEmpty
          icon="i-lucide-door-closed"
          title="No rooms found"
          description="Get started by creating your first coworking space."
        >
          <template #actions>
            <UButton
              label="Create Room"
              icon="i-lucide-plus"
              @click="isCreateModalOpen = true"
            />
          </template>
        </UEmpty>
      </div>
      
      <UTable v-else :data="rooms" :columns="columns" class="w-full">
        <template #image-cell="{ row }">
          <div class="w-16 h-12 rounded-lg overflow-hidden bg-slate-800">
            <img
              v-if="row.original.image_url"
              :src="row.original.image_url"
              :alt="row.original.name"
              class="w-full h-full object-cover"
            />
            <div v-else class="w-full h-full flex items-center justify-center">
              <UIcon name="i-lucide-image" class="w-5 h-5 text-slate-600" />
            </div>
          </div>
        </template>
        
        <template #name-cell="{ row }">
          <span class="font-medium text-white">{{ row.original.name }}</span>
        </template>
        
        <template #capacity-cell="{ row }">
          <UBadge color="primary" variant="subtle">
            <UIcon name="i-lucide-users" class="w-3 h-3 mr-1" />
            {{ row.original.capacity }} people
          </UBadge>
        </template>
        
        <template #description-cell="{ row }">
          <span class="text-slate-400 line-clamp-2 max-w-xs">{{ row.original.description }}</span>
        </template>
        
        <template #actions-cell="{ row }">
          <UDropdownMenu
            :items="[
              [{
                label: 'Edit',
                icon: 'i-lucide-pencil',
                disabled: true
              }],
              [{
                label: 'Delete',
                icon: 'i-lucide-trash-2',
                color: 'error',
                onSelect: () => openDeleteDialog(row.original.id)
              }]
            ]"
          >
            <UButton
              icon="i-lucide-more-horizontal"
              variant="ghost"
              size="sm"
            />
          </UDropdownMenu>
        </template>
      </UTable>
    </div>
    
    <!-- Create Room Modal -->
    <UModal v-model:open="isCreateModalOpen">
      <template #content>
        <UCard class="w-full max-w-lg">
          <template #header>
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
                <UIcon name="i-lucide-plus" class="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 class="text-lg font-semibold text-white">Create New Room</h3>
                <p class="text-sm text-slate-400">Add a new coworking space to the platform</p>
              </div>
            </div>
          </template>
          
          <UForm
            :schema="createRoomSchema"
            :state="createRoomState"
            class="space-y-4"
            @submit="onCreateRoom"
          >
            <UFormField label="Room Name" name="name" required>
              <UInput
                v-model="createRoomState.name"
                placeholder="e.g., Conference Room A"
                icon="i-lucide-door-open"
              />
            </UFormField>
            
            <UFormField label="Capacity" name="capacity" required>
              <UInput
                v-model.number="createRoomState.capacity"
                type="number"
                :min="1"
                :max="100"
                placeholder="4"
                icon="i-lucide-users"
              />
            </UFormField>
            
            <UFormField label="Description" name="description" required>
              <UTextarea
                v-model="createRoomState.description"
                placeholder="Describe the room features, amenities, etc."
                :rows="3"
              />
            </UFormField>
            
            <UFormField label="Image URL" name="image_url" hint="Optional">
              <UInput
                v-model="createRoomState.image_url"
                placeholder="https://example.com/image.jpg"
                icon="i-lucide-image"
              />
            </UFormField>
            
            <div class="flex gap-3 justify-end pt-4">
              <UButton
                label="Cancel"
                variant="ghost"
                @click="isCreateModalOpen = false"
              />
              <UButton
                type="submit"
                label="Create Room"
                :loading="isCreating"
              />
            </div>
          </UForm>
        </UCard>
      </template>
    </UModal>
    
    <!-- Delete Confirmation Dialog -->
    <UModal v-model:open="isDeleteDialogOpen">
      <template #content>
        <UCard class="w-full max-w-md">
          <template #header>
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                <UIcon name="i-lucide-alert-triangle" class="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 class="text-lg font-semibold text-white">Delete Room</h3>
                <p class="text-sm text-slate-400">This action cannot be undone</p>
              </div>
            </div>
          </template>
          
          <p class="text-slate-300">
            Are you sure you want to delete 
            <span class="font-semibold text-white">{{ roomToDelete?.name }}</span>? 
            All associated bookings will also be removed.
          </p>
          
          <template #footer>
            <div class="flex gap-3 justify-end">
              <UButton
                label="Cancel"
                variant="ghost"
                @click="isDeleteDialogOpen = false"
              />
              <UButton
                label="Delete Room"
                color="error"
                :loading="isDeleting"
                @click="confirmDeleteRoom"
              />
            </div>
          </template>
        </UCard>
      </template>
    </UModal>
  </div>
</template>
