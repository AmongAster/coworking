<script setup lang="ts">
const { user, logout } = useAuth()

const route = useRoute()

const navItems = [
  { label: 'Overview', icon: 'i-lucide-layout-dashboard', to: '/admin' },
  { label: 'Rooms', icon: 'i-lucide-door-open', to: '/admin/rooms' },
  { label: 'Bookings', icon: 'i-lucide-calendar-check', to: '/admin/bookings' },
]

const isSidebarOpen = ref(true)

const isActive = (path: string) => {
  if (path === '/admin') {
    return route.path === '/admin'
  }
  return route.path.startsWith(path)
}
</script>

<template>
  <div class="min-h-screen bg-slate-950 flex">
    <!-- Sidebar -->
    <aside
      class="fixed inset-y-0 left-0 z-50 flex flex-col w-64 bg-slate-900/80 backdrop-blur-xl border-r border-slate-800 transition-transform duration-300 lg:translate-x-0"
      :class="isSidebarOpen ? 'translate-x-0' : '-translate-x-full'"
    >
      <!-- Logo -->
      <div class="flex items-center gap-3 h-16 px-6 border-b border-slate-800">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <UIcon name="i-lucide-shield" class="w-5 h-5 text-white" />
        </div>
        <div>
          <span class="font-bold text-white text-lg">Admin</span>
          <p class="text-xs text-slate-400">CoWork Space</p>
        </div>
      </div>
      
      <!-- Navigation -->
      <nav class="flex-1 p-4 space-y-1">
        <NuxtLink
          v-for="item in navItems"
          :key="item.to"
          :to="item.to"
          class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200"
          :class="isActive(item.to) 
            ? 'bg-gradient-to-r from-indigo-600/20 to-violet-600/20 text-indigo-400 border border-indigo-500/30 shadow-lg shadow-indigo-500/10' 
            : 'text-slate-400 hover:text-white hover:bg-slate-800/50'"
        >
          <UIcon :name="item.icon" class="w-5 h-5" />
          {{ item.label }}
        </NuxtLink>
      </nav>
      
      <!-- User Section -->
      <div class="p-4 border-t border-slate-800">
        <div class="flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-800/50">
          <UAvatar 
            :alt="user?.email || 'Admin'" 
            icon="i-lucide-user"
            size="sm"
            class="bg-gradient-to-br from-indigo-500 to-violet-600"
          />
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium text-white truncate">{{ user?.email }}</p>
            <p class="text-xs text-indigo-400">Administrator</p>
          </div>
        </div>
        
        <div class="mt-3 flex gap-2">
          <NuxtLink to="/" class="flex-1">
            <UButton
              label="Main Site"
              variant="outline"
              icon="i-lucide-external-link"
              size="sm"
              block
            />
          </NuxtLink>
          <UButton
            icon="i-lucide-log-out"
            variant="ghost"
            color="error"
            size="sm"
            @click="logout()"
          />
        </div>
      </div>
    </aside>
    
    <!-- Mobile Overlay -->
    <div
      v-if="isSidebarOpen"
      class="fixed inset-0 z-40 bg-black/50 lg:hidden"
      @click="isSidebarOpen = false"
    />
    
    <!-- Main Content -->
    <div class="flex-1 lg:ml-64">
      <!-- Top Bar -->
      <header class="sticky top-0 z-30 h-16 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800 flex items-center px-4 lg:px-8">
        <UButton
          icon="i-lucide-menu"
          variant="ghost"
          class="lg:hidden mr-4"
          @click="isSidebarOpen = !isSidebarOpen"
        />
        
        <div class="flex-1">
          <h1 class="text-lg font-semibold text-white">
            {{ route.meta.title || 'Admin Dashboard' }}
          </h1>
        </div>
        
        <div class="flex items-center gap-4">
          <UButton
            icon="i-lucide-bell"
            variant="ghost"
            class="relative"
          >
            <span class="absolute -top-1 -right-1 w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
          </UButton>
        </div>
      </header>
      
      <!-- Page Content -->
      <main class="p-4 lg:p-8">
        <slot />
      </main>
    </div>
  </div>
</template>
