<template>
  <UApp :ui="{ colors: { primary: 'indigo', neutral: 'slate' } }">
    <NuxtPage />
  </UApp>
</template>
