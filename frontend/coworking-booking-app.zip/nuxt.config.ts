export default defineNuxtConfig({
  devtools: { enabled: true },
  modules: ['@nuxt/ui'],
  css: ['~/assets/css/main.css'],
  
  runtimeConfig: {
    public: {
      apiBase: 'http://localhost:5000/api'
    }
  },
  
  app: {
    head: {
      title: 'CoWork Space - Book Your Workspace',
      meta: [
        { name: 'description', content: 'Modern coworking space booking application' }
      ]
    }
  }
})
