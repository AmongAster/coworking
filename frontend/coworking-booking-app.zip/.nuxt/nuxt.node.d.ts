/// <reference types="@nuxt/ui" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@4.4.6_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@types+nod_2a26327fc871607f9d3ef1b3f18f7bee/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.4.6_@babel+plugin-syntax-typescript@7.29.7_@babel+core@7.29.7__db0_93544dc9fce81dc6e7c1606fa5855d68/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
